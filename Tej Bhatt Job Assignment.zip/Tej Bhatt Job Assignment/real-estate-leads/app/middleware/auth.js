export const protect = (req, res, next) => {
  // Mock: attach a fake user (replace with real JWT logic)
  req.user = { _id: "64c123456789abcdef123456" };
  next();
};
