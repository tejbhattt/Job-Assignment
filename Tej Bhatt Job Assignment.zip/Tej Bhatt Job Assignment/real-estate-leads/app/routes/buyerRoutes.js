import express from "express";
import { createBuyer } from "../controllers/buyerController.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

// POST /buyers/new
router.post("/new", protect, createBuyer);

export default router;
