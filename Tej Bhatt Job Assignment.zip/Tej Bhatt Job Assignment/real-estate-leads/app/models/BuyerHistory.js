import mongoose from "mongoose";

const buyerHistorySchema = new mongoose.Schema({
  buyerId: { type: mongoose.Schema.Types.ObjectId, ref: "Buyer", required: true },
  action: { type: String, required: true, default: "CREATED" },
  timestamp: { type: Date, default: Date.now },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
}, { timestamps: true });

export default mongoose.model("BuyerHistory", buyerHistorySchema);
