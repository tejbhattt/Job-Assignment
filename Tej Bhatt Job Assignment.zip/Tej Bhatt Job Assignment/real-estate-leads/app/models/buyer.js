import mongoose from "mongoose";

const buyerSchema = new mongoose.Schema({
  fullName: { type: String, required: true, minlength: 2 },
  email: { type: String },
  phone: { type: String, required: true, match: /^[0-9]{10,15}$/ },
  city: { type: String, required: true },
  propertyType: { type: String, required: true, enum: ["Apartment", "Villa", "Plot", "Commercial"] },
  bhk: { type: Number },
  purpose: { type: String },
  budgetMin: { type: Number },
  budgetMax: { type: Number },
  timeline: { type: String },
  source: { type: String },
  notes: { type: String },
  tags: [{ type: String }],
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
}, { timestamps: true });

export default mongoose.model("Buyer", buyerSchema);
