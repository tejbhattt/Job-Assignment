import Buyer from "../models/buyer.js";
import BuyerHistory from "../models/BuyerHistory.js";

export const createBuyer = async (req, res) => {
  try {
    const {
      fullName, email, phone, city, propertyType,
      bhk, purpose, budgetMin, budgetMax,
      timeline, source, notes, tags
    } = req.body;

    const ownerId = req.user?._id; // from auth middleware

    // Validation
    if (!fullName || fullName.length < 2)
      return res.status(400).json({ error: "Full name must be at least 2 characters" });

    if (!/^[0-9]{10,15}$/.test(phone))
      return res.status(400).json({ error: "Phone must be numeric 10-15 digits" });

    if (email && !/^\S+@\S+\.\S+$/.test(email))
      return res.status(400).json({ error: "Invalid email" });

    if (budgetMin && budgetMax && budgetMax < budgetMin)
      return res.status(400).json({ error: "budgetMax must be >= budgetMin" });

    if (["Apartment", "Villa"].includes(propertyType) && !bhk)
      return res.status(400).json({ error: "BHK is required for Apartment or Villa" });

    // Create Buyer
    const buyer = await Buyer.create({
      fullName, email, phone, city, propertyType,
      bhk, purpose, budgetMin, budgetMax,
      timeline, source, notes, tags, ownerId
    });

    // Log History
    await BuyerHistory.create({
      buyerId: buyer._id,
      action: "CREATED",
      ownerId
    });

    res.status(201).json({ message: "Buyer created successfully", buyer });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
};
